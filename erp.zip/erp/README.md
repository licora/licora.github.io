# ERP Gate Setup

This project protects an ERP by checking:

- current domain is allowed
- license key exists in the remote JSON
- license has not expired

The public config is hosted at:

`https://licora.github.io/erp.json`

## Files

- `stealth_validation_dev.php` - main validation logic
- `404_page.html` - page shown when access is blocked
- `example_config.json` - sample remote JSON format
- `.env.example` - sample ERP environment variables
- `integration_examples.php` - example snippets for ERP files

## Remote JSON Format

Host this JSON on GitHub Pages or any public URL.

Example:

```json
{
  "cfg": {
    "X9A7K": {
      "targets": [
        "example.com",
        "erp.example.com",
        "*.example.net",
        "localhost"
      ],
      "expires": "2026-12-31"
    }
  }
}
```

Meaning:

- `cfg` = config container
- `X9A7K` = license key
- `targets` = allowed domains
- `expires` = last valid date in `YYYY-MM-DD`

## ERP Setup

Copy these files into your ERP root:

- `stealth_validation_dev.php`
- `404_page.html`

Create ERP `.env` file:

```env
ERP_GATE_SOURCE_B64=aHR0cHM6Ly9saWNvcmEuZ2l0aHViLmlvL2VycC5qc29u
ERP_GATE_LICENSE=X9A7K
ERP_GATE_CACHE_TTL=300
```

Notes:

- `ERP_GATE_SOURCE_B64` is the base64 version of `https://licora.github.io/erp.json`
- `ERP_GATE_LICENSE` must match the key inside remote JSON
- `ERP_GATE_CACHE_TTL=300` means cache refresh every 300 seconds
- if `ERP_GATE_SOURCE_B64` or `ERP_GATE_LICENSE` is removed from `.env`, access fails with `404`

## config.php

Add this near the top of ERP `config.php`:

```php
define('ERP_GATE_CACHE_FILE', __DIR__ . '/storage/cache/erp_gate.json');
define('ERP_GATE_CACHE_TTL', 300);
define('ERP_GATE_404_FILE', __DIR__ . '/404_page.html');

require_once __DIR__ . '/stealth_validation_dev.php';
erp_gate_bootstrap();
```

If your ERP does not use `storage/cache`, change the cache path to any writable location.

## index.php

Add this near the top of public `index.php`:

```php
require_once __DIR__ . '/config.php';

if (!defined('SYS_OK')) {
    http_response_code(404);
    require __DIR__ . '/404_page.html';
    exit();
}
```

## admin/index.php

Add the same protection in admin entry points:

```php
require_once dirname(__DIR__) . '/config.php';

if (!defined('SYS_OK')) {
    http_response_code(404);
    require dirname(__DIR__) . '/404_page.html';
    exit();
}
```

## Protect Sensitive Files

Add this guard to any sensitive PHP file that should never run directly:

```php
if (!defined('SYS_OK')) {
    http_response_code(404);
    require __DIR__ . '/404_page.html';
    exit();
}
```

## How License Matching Works

Example remote JSON:

```json
{
  "cfg": {
    "X9A7K": {
      "targets": ["erp.example.com"],
      "expires": "2026-12-31"
    }
  }
}
```

Example ERP `.env`:

```env
ERP_GATE_LICENSE=X9A7K
```

If both match, and the current domain is inside `targets`, access is allowed.

## Add New Client

For a new client:

1. Add a new key inside remote JSON.
2. Set that same key in the client's ERP `.env`.
3. Add the client's allowed domains in `targets`.
4. Set the expiry date in `expires`.

Example:

```json
{
  "cfg": {
    "CLIENT_001": {
      "targets": ["clientdomain.com", "erp.clientdomain.com"],
      "expires": "2026-12-31"
    }
  }
}
```

ERP `.env`:

```env
ERP_GATE_LICENSE=CLIENT_001
```

## Optional Compatibility

The validator also supports old short keys:

```json
{
  "cfg": {
    "X9A7K": {
      "t": ["example.com"],
      "e": "2026-12-31"
    }
  }
}
```

Recommended format is still:

- `targets`
- `expires`

## Quick Check

If setup is correct:

- remote JSON opens in browser
- ERP `.env` has correct license key
- current domain matches `targets`
- expiry date is not passed
- cache folder is writable
- `.env` still contains `ERP_GATE_SOURCE_B64` and `ERP_GATE_LICENSE`

If any check fails, ERP shows `404_page.html`.
