<?php

/*
 * Saved integration examples for the ERP.
 *
 * 1. Place stealth_validation_dev.php in the ERP root.
 * 2. Place 404_page.html in the ERP root.
 * 3. Add the snippets below into the matching files.
 */

/*
|--------------------------------------------------------------------------
| .env
|--------------------------------------------------------------------------
|
| Keep the public map URL encoded in ERP and store the license privately.
|
| Public URL: https://licora.github.io/erp.json
| ERP_GATE_SOURCE_B64=aHR0cHM6Ly9saWNvcmEuZ2l0aHViLmlvL2VycC5qc29u
| ERP_GATE_LICENSE=X9A7K
|
*/

/*
|--------------------------------------------------------------------------
| config.php
|--------------------------------------------------------------------------
|
| Load the gate as early as possible.
|
*/

define('ERP_GATE_CACHE_FILE', __DIR__ . '/storage/cache/erp_gate.json');
define('ERP_GATE_CACHE_TTL', 300);
define('ERP_GATE_404_FILE', __DIR__ . '/404_page.html');

/*
|--------------------------------------------------------------------------
| example_config.json
|--------------------------------------------------------------------------
|
| Recommended readable format:
| {
|   "cfg": {
|     "X9A7K": {
|       "targets": ["example.com", "erp.example.com", "*.example.net", "localhost"],
|       "expires": "2026-12-31"
|     }
|   }
| }
|
| Backward-compatible short keys also work:
| "t" => targets, "e" => expires
|
| ERP side can load the matching license from .env:
| ERP_GATE_LICENSE=X9A7K
|
*/

require_once __DIR__ . '/stealth_validation_dev.php';
erp_gate_bootstrap();

/*
|--------------------------------------------------------------------------
| index.php
|--------------------------------------------------------------------------
|
| Keep this near the top of the public entry point.
|
*/

require_once __DIR__ . '/config.php';

if (!defined('SYS_OK')) {
    http_response_code(404);
    require __DIR__ . '/404_page.html';
    exit();
}

/*
|--------------------------------------------------------------------------
| admin/index.php
|--------------------------------------------------------------------------
|
| Use the same guard in admin entry points.
|
*/

require_once dirname(__DIR__) . '/config.php';

if (!defined('SYS_OK')) {
    http_response_code(404);
    require dirname(__DIR__) . '/404_page.html';
    exit();
}

/*
|--------------------------------------------------------------------------
| Core file guard
|--------------------------------------------------------------------------
|
| Add this to any sensitive PHP file that should never run on its own.
|
*/

if (!defined('SYS_OK')) {
    http_response_code(404);
    require __DIR__ . '/404_page.html';
    exit();
}
