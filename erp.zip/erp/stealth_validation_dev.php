<?php

/**
 * Readable ERP remote gate.
 *
 * Keep the JSON source readable and managed outside the app:
 * {
 *   "cfg": {
 *     "X9A7K": {
 *       "targets": ["example.com", "*.example.com"],
 *       "expires": "2026-12-31"
 *     }
 *   }
 * }
 *
 * Usage:
 * 1. Add ERP_GATE_SOURCE_B64 and ERP_GATE_LICENSE to .env,
 *    or define ERP_GATE_SOURCE and ERP_GATE_KEY before including this file.
 *    By default, missing .env license/source values fail closed with 404.
 * 2. Call erp_gate_bootstrap().
 * 3. Protect core entry points with the SYS_OK check from integration_examples.php.
 */

if (!function_exists('erp_gate_bootstrap')) {
    function erp_gate_bootstrap($overrides = array())
    {
        if (defined('SYS_OK')) {
            return;
        }

        $settings = array_merge(erp_gate_defaults(), $overrides);

        if (!erp_gate_has_required_runtime($settings)) {
            erp_gate_fail($settings['page_404']);
        }

        $host = erp_gate_current_host();

        if ($host === '') {
            erp_gate_fail($settings['page_404']);
        }

        $map = erp_gate_load_map($settings);

        if ($map === null || !erp_gate_allows($map, (string) $settings['key'], $host)) {
            erp_gate_fail($settings['page_404']);
        }

        define('SYS_OK', true);
    }
}

if (!function_exists('erp_gate_defaults')) {
    function erp_gate_defaults()
    {
        return [
            'source' => erp_gate_resolve_source(),
            'key' => erp_gate_resolve_key(),
            'require_env' => erp_gate_truthy(erp_gate_setting('ERP_GATE_REQUIRE_ENV', '1')),
            'cache_file' => (string) erp_gate_setting('ERP_GATE_CACHE_FILE', __DIR__ . '/.cache/erp_gate.json'),
            'cache_ttl' => (int) erp_gate_setting('ERP_GATE_CACHE_TTL', 300),
            'timeout' => (int) erp_gate_setting('ERP_GATE_TIMEOUT', 5),
            'page_404' => (string) erp_gate_setting('ERP_GATE_404_FILE', __DIR__ . '/404_page.html'),
        ];
    }
}

if (!function_exists('erp_gate_has_required_runtime')) {
    function erp_gate_has_required_runtime($settings)
    {
        if (!is_array($settings)) {
            return false;
        }

        $source = isset($settings['source']) ? trim((string) $settings['source']) : '';
        $key = isset($settings['key']) ? trim((string) $settings['key']) : '';

        if ($source === '' || $key === '') {
            return false;
        }

        $requireEnv = !empty($settings['require_env']);

        if (!$requireEnv) {
            return true;
        }

        return erp_gate_has_required_env_values();
    }
}

if (!function_exists('erp_gate_has_required_env_values')) {
    function erp_gate_has_required_env_values()
    {
        $envMap = erp_gate_env_map();

        $hasSource = false;
        if (array_key_exists('ERP_GATE_SOURCE_B64', $envMap) && trim((string) $envMap['ERP_GATE_SOURCE_B64']) !== '') {
            $hasSource = true;
        } elseif (array_key_exists('ERP_GATE_SOURCE', $envMap) && trim((string) $envMap['ERP_GATE_SOURCE']) !== '') {
            $hasSource = true;
        }

        $hasKey = false;
        if (array_key_exists('ERP_GATE_LICENSE', $envMap) && trim((string) $envMap['ERP_GATE_LICENSE']) !== '') {
            $hasKey = true;
        } elseif (array_key_exists('ERP_GATE_KEY', $envMap) && trim((string) $envMap['ERP_GATE_KEY']) !== '') {
            $hasKey = true;
        }

        return $hasSource && $hasKey;
    }
}

if (!function_exists('erp_gate_truthy')) {
    function erp_gate_truthy($value)
    {
        $value = strtolower(trim((string) $value));

        return !in_array($value, array('', '0', 'false', 'off', 'no'), true);
    }
}

if (!function_exists('erp_gate_resolve_source')) {
    function erp_gate_resolve_source()
    {
        $source = trim((string) erp_gate_setting('ERP_GATE_SOURCE', ''));

        if ($source !== '') {
            return $source;
        }

        $encoded = trim((string) erp_gate_setting('ERP_GATE_SOURCE_B64', ''));

        if ($encoded === '') {
            return '';
        }

        $decoded = base64_decode($encoded, true);
        return $decoded === false ? '' : trim($decoded);
    }
}

if (!function_exists('erp_gate_resolve_key')) {
    function erp_gate_resolve_key()
    {
        $license = trim((string) erp_gate_setting('ERP_GATE_LICENSE', ''));

        if ($license !== '') {
            return $license;
        }

        return trim((string) erp_gate_setting('ERP_GATE_KEY', ''));
    }
}

if (!function_exists('erp_gate_setting')) {
    function erp_gate_setting($name, $default = '')
    {
        if (defined($name)) {
            return constant($name);
        }

        $envValue = getenv($name);
        if ($envValue !== false && $envValue !== '') {
            return $envValue;
        }

        $envMap = erp_gate_env_map();
        if (array_key_exists($name, $envMap) && $envMap[$name] !== '') {
            return $envMap[$name];
        }

        return $default;
    }
}

if (!function_exists('erp_gate_env_map')) {
    function erp_gate_env_map()
    {
        static $envMap = null;

        if ($envMap !== null) {
            return $envMap;
        }

        $envMap = [];
        $envFile = erp_gate_env_file();

        if ($envFile === '' || !is_file($envFile)) {
            return $envMap;
        }

        $lines = @file($envFile, FILE_IGNORE_NEW_LINES);

        if (!is_array($lines)) {
            return $envMap;
        }

        foreach ($lines as $line) {
            $line = trim($line);

            if ($line === '' || $line[0] === '#') {
                continue;
            }

            if (strpos($line, '=') === false) {
                continue;
            }

            list($name, $value) = explode('=', $line, 2);
            $name = trim($name);

            if (strpos($name, 'export ') === 0) {
                $name = trim(substr($name, 7));
            }

            if ($name === '') {
                continue;
            }

            $envMap[$name] = erp_gate_clean_env_value($value);
        }

        return $envMap;
    }
}

if (!function_exists('erp_gate_env_file')) {
    function erp_gate_env_file()
    {
        if (defined('ERP_GATE_ENV_FILE')) {
            return (string) ERP_GATE_ENV_FILE;
        }

        $envFile = getenv('ERP_GATE_ENV_FILE');
        if ($envFile !== false && $envFile !== '') {
            return (string) $envFile;
        }

        return __DIR__ . '/.env';
    }
}

if (!function_exists('erp_gate_clean_env_value')) {
    function erp_gate_clean_env_value($value)
    {
        $value = trim((string) $value);
        $length = strlen($value);

        if ($length >= 2) {
            $first = $value[0];
            $last = $value[$length - 1];

            if (($first === '"' && $last === '"') || ($first === "'" && $last === "'")) {
                return substr($value, 1, -1);
            }
        }

        return $value;
    }
}

if (!function_exists('erp_gate_load_map')) {
    function erp_gate_load_map($settings)
    {
        $cacheFile = (string) $settings['cache_file'];
        $ttl = max(0, (int) $settings['cache_ttl']);
        $cachedRaw = erp_gate_read_cache($cacheFile, $ttl);

        if ($cachedRaw !== null) {
            $decoded = erp_gate_decode_map($cachedRaw);
            if ($decoded !== null) {
                return $decoded;
            }
        }

        $remoteRaw = erp_gate_http_get((string) $settings['source'], (int) $settings['timeout']);

        if ($remoteRaw !== null) {
            $decoded = erp_gate_decode_map($remoteRaw);
            if ($decoded !== null) {
                erp_gate_write_cache($cacheFile, $remoteRaw);
                return $decoded;
            }
        }

        $staleRaw = erp_gate_read_stale_cache($cacheFile);

        if ($staleRaw !== null) {
            return erp_gate_decode_map($staleRaw);
        }

        return null;
    }
}

if (!function_exists('erp_gate_read_cache')) {
    function erp_gate_read_cache($cacheFile, $ttl)
    {
        if (!is_file($cacheFile)) {
            return null;
        }

        if ((time() - (int) @filemtime($cacheFile)) > $ttl) {
            return null;
        }

        $contents = @file_get_contents($cacheFile);
        return $contents === false ? null : $contents;
    }
}

if (!function_exists('erp_gate_read_stale_cache')) {
    function erp_gate_read_stale_cache($cacheFile)
    {
        if (!is_file($cacheFile)) {
            return null;
        }

        $contents = @file_get_contents($cacheFile);
        return $contents === false ? null : $contents;
    }
}

if (!function_exists('erp_gate_write_cache')) {
    function erp_gate_write_cache($cacheFile, $payload)
    {
        $dir = dirname($cacheFile);

        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        @file_put_contents($cacheFile, $payload, LOCK_EX);
    }
}

if (!function_exists('erp_gate_http_get')) {
    function erp_gate_http_get($url, $timeout)
    {
        if ($url === '') {
            return null;
        }

        $scheme = parse_url($url, PHP_URL_SCHEME);
        $isHttp = in_array($scheme, array('http', 'https'), true);

        if ($scheme !== null && !$isHttp) {
            $body = @file_get_contents($url);
            return $body === false ? null : $body;
        }

        if (function_exists('curl_init')) {
            $ch = curl_init($url);

            if ($ch === false) {
                return null;
            }

            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS => 3,
                CURLOPT_CONNECTTIMEOUT => $timeout,
                CURLOPT_TIMEOUT => $timeout,
                CURLOPT_USERAGENT => 'ERP-Gate/1.0',
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_HTTPHEADER => ['Accept: application/json'],
            ]);

            $body = curl_exec($ch);
            $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);

            if ($body === false || $status < 200 || $status >= 300) {
                return null;
            }

            return is_string($body) ? $body : null;
        }

        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'timeout' => $timeout,
                'header' => "Accept: application/json\r\nUser-Agent: ERP-Gate/1.0\r\n",
            ],
            'ssl' => [
                'verify_peer' => true,
                'verify_peer_name' => true,
            ],
        ]);

        $body = @file_get_contents($url, false, $context);

        if ($body === false) {
            return null;
        }

        return $body;
    }
}

if (!function_exists('erp_gate_decode_map')) {
    function erp_gate_decode_map($payload)
    {
        $decoded = json_decode($payload, true);

        if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
            return null;
        }

        return $decoded;
    }
}

if (!function_exists('erp_gate_allows')) {
    function erp_gate_allows($map, $key, $host)
    {
        if ($key === '' || !isset($map['cfg'][$key]) || !is_array($map['cfg'][$key])) {
            return false;
        }

        $item = erp_gate_normalize_entry($map['cfg'][$key]);

        if ($item === null) {
            return false;
        }

        if (!erp_gate_date_open($item['e'])) {
            return false;
        }

        return erp_gate_host_matches($host, $item['t']);
    }
}

if (!function_exists('erp_gate_normalize_entry')) {
    function erp_gate_normalize_entry($item)
    {
        if (!is_array($item)) {
            return null;
        }

        $targets = null;
        if (isset($item['t']) && is_array($item['t'])) {
            $targets = $item['t'];
        } elseif (isset($item['targets']) && is_array($item['targets'])) {
            $targets = $item['targets'];
        }

        $expires = null;
        if (isset($item['e']) && is_string($item['e'])) {
            $expires = $item['e'];
        } elseif (isset($item['expires']) && is_string($item['expires'])) {
            $expires = $item['expires'];
        }

        if ($targets === null || $expires === null) {
            return null;
        }

        return [
            't' => $targets,
            'e' => $expires,
        ];
    }
}

if (!function_exists('erp_gate_date_open')) {
    function erp_gate_date_open($dateText)
    {
        if (!is_string($dateText) || preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateText) !== 1) {
            return false;
        }

        return date('Y-m-d') <= $dateText;
    }
}

if (!function_exists('erp_gate_host_matches')) {
    function erp_gate_host_matches($host, $patterns)
    {
        $host = strtolower(trim($host));

        foreach ($patterns as $pattern) {
            if (!is_string($pattern) || $pattern === '') {
                continue;
            }

            $pattern = strtolower(trim($pattern));

            if ($pattern === $host) {
                return true;
            }

            $quoted = preg_quote($pattern, '/');
            $regex = '/^' . str_replace('\*', '.*', $quoted) . '$/i';

            if (preg_match($regex, $host) === 1) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('erp_gate_current_host')) {
    function erp_gate_current_host()
    {
        $host = '';

        if (!empty($_SERVER['HTTP_HOST'])) {
            $host = (string) $_SERVER['HTTP_HOST'];
        } elseif (!empty($_SERVER['SERVER_NAME'])) {
            $host = (string) $_SERVER['SERVER_NAME'];
        }

        $host = trim(strtolower($host));

        if ($host === '') {
            return '';
        }

        if (strpos($host, ':') !== false) {
            $host = (string) strstr($host, ':', true);
        }

        return trim($host, '.');
    }
}

if (!function_exists('erp_gate_fail')) {
    function erp_gate_fail($page404)
    {
        if (!headers_sent()) {
            http_response_code(404);
            header('Content-Type: text/html; charset=UTF-8');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        }

        if (is_file($page404) && is_readable($page404)) {
            @readfile($page404);
        } else {
            echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>404</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:linear-gradient(135deg,#0f172a,#1d4ed8,#06b6d4);font-family:Segoe UI,Arial,sans-serif;color:#fff}.wrap{text-align:center;padding:32px}.code{font-size:clamp(88px,18vw,180px);font-weight:800;letter-spacing:.08em}.title{font-size:clamp(22px,4vw,34px);margin-top:8px}</style></head><body><div class="wrap"><div class="code">404</div><div class="title">Page Not Found</div></div></body></html>';
        }

        exit();
    }
}
